/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program3;

/**
 *
 * @author Louis
 */
public class Course {
    String id;
    String instructor;
    
    public Course(String a, String b){
        id = a;
        instructor = b;
    }
}
